package es.sidelab.cubedrop;

import org.springframework.stereotype.Component;

@Component
public class Jugadores{
	
	private int numJug;
	
	public Jugadores() {
		this.numJug = 1;
	}
	
	public int getJugadores() {
		return numJug;
	}
	
	public void setJugadores(int numJug) {
		this.numJug = numJug;
	}
}