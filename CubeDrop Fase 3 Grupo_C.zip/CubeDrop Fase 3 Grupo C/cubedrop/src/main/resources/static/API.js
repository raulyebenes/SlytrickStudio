

/*$(document).ready(function(){
   
    $("#add-button").click(function(){
       var value = $('#value-input').val();
       //$('#info').html("<img src = 'spinner.gif'/>")
       
       $.ajax({
          url:  "https://www.googleapis.com/books/v1/volumes?q=intitle:" + value
       }).done(function (data){
           
           $('#info').empty();
           
           for(var i=0; i<data.items.length; i++){
               
               var book = data.items[i].volumeInfo;
               
               $('#info').append("<div><h3>" 
                       + book.title + "</h3>"
                       + "<p>"+ book.description
                       +"</p>"
                                +"</div>");
                       +"<img src=" + "cazultitulo.png" + " align=" + "top" + ">"
                       +"<img src=" + "crojotitulo.png" + " align=" + "bottom" + ">");
               
                
           }
           $('#info').append(
             
             "<img " + "src=" + "jugador1.png" + " class=" + "jug1" + ">"
             +"<img " + "src=" + "jugador2.png" + " class=" + "jug2" + ">"
             +"<img " + "src=" + "cazultitulo.png" + " class=" + "cubo" + ">"
             +"<img " + "src=" + "crojotitulo.png" + " class=" + "cubo2" + ">") ;  
       
        });
    });
     
});*/



function get(callback){
    
    $.ajax({
        method: 'GET',
        url: 'jugadores/getNum',
        headers: {
            "Content-Type": "application/json",
        }
        
    }).done(function(data){
        //callback(data);
        jugadores = data;
        //console.log(jugadores);
    });
}

/*function mostrarConectado(){
    if(jugadores === 2){
            $('#info').append(
                  "<img " + "src=" + "jugador1.png" + " class=" + "jug1" + ">"
                  +"<img " + "src=" + "cazultitulo.png" + " class=" + "cubo" + ">"
            );
        }
        if(jugadores === 3){
            $('#info').append(
                  "<img " + "src=" + "jugador1.png" + " class=" + "jug1" + ">"
                  +"<img " + "src=" + "cazultitulo.png" + " class=" + "cubo" + ">"
                  +"<img " + "src=" + "jugador2.png" + " class=" + "jug2" + ">"
                  +"<img " + "src=" + "crojotitulo.png" + " class=" + "cubo2" + ">"
            );
           // setTimeOut(()=>{this.scene.start("juego");}, 3000);
        }
        if(jugadores>3){
            alert("jugadores de mas");
        }
}*/

function conectarJug(){
    jugadores++;
    $.ajax({
        method: "PUT",
        url: 'jugadores/connect',
        data: jugadores,
        processData: false,
        headers: {
            "Content-Type": "application/json",
        }     
    }).done(function() {
            console.log("Conexion exitosa: " + jugadores + " jugadores");
    }).fail(function(){
            console.log("Error al conectar");
    });
}

function desconectarJug(){
    jugadores--;
    $.ajax({
        method: "PUT",
        url: 'jugadores/disconnect',
        data: jugadores,
        processData: false,
        headers: {
            "Content-Type": "application/json",
        }        
    }).done(function() {
            console.log("Desconexion exitosa: " + jugadores + " jugadores");
    }).fail(function(){
            console.log("Error al desconectar");
    });
}

/*$(document).ready(function(){
   var botJugar = $("#botJugar");
   var botSalir = $("#botSalir");
   var data;
   
   botJugar.click(function(){
       this.scene.start("lobby");
       jugadores++;
       conectarJug();
       //data = get();
       mostrarConectado(data);
   });
   
   botSalir.click(function(){
       this.scene.start("menu");
        jugadores--;
       desconectarJug();
      //data = get();
      mostrarConectado(data);
   });
   
   
});*/