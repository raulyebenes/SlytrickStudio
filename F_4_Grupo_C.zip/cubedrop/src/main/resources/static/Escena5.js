/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


class Escena5 extends Phaser.Scene{

    constructor() {
        super("creditos");
    }
    
    preload(){
        this.load.image("fondo", "assets/fondo.png");
        this.load.image("nombres", "assets/nombres.png");

    }
    
    create() {
        
        let fondo = this.add.image(game.config.width/2, game.config.height/2, "fondo");
        fondo.setInteractive();
        fondo.on("pointerup", ()=>{
            this.scene.start("menu");
        })
        
        let nombres = this.add.image(game.config.width/2, game.config.height/2, "nombres");
        nombres.setInteractive();
        nombres.on("pointerup", ()=>{
            this.scene.start("menu");
        })
        
    }
}
   