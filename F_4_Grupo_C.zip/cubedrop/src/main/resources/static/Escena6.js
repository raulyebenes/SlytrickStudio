

var jugador1;
var jugador2;
var cuboAz;
var cuboRo;

var delayInMilliseconds = 200; //1 second
var entrarGet = true;

class Escena6 extends Phaser.Scene{

    constructor() {
        super("lobby");
    }


    preload(){
        this.load.image("cubo_azul", "assets/cazultitulo.png");
        this.load.image("cubo_rojo", "assets/crojotitulo.png");
        this.load.image("jugador1", "assets/jugador1.png");
        this.load.image("jugador2", "assets/jugador2.png");
        this.load.image("botonSalir", "assets/but_salir.png");
        this.load.image("cuentaAtras", "assets/cuentaAtras.png");
        this.load.image("fondo", "assets/fondo.png");
    }

    create() {
        this.add.image(250,400, "fondo");
        jugador1 = this.add.image(250,100, "jugador1").setVisible(false);
        jugador2 =this.add.image(250,450, "jugador2").setVisible(false);
        cuboAz = this.add.image(250,250, "cubo_rojo").setVisible(false).setScale(0.4);
        cuboRo = this.add.image(250,600, "cubo_azul").setVisible(false).setScale(0.4);
        cuentaAtras = this.add.image(175,750, "cuentaAtras").setVisible(false);
        
        
        let botonSalir = this.add.image(400,750, "botonSalir");
        
        botonSalir.setInteractive();
        
        botonSalir.on("pointerup", ()=>{
            desconectarJug();
            this.scene.start("menu");
        })
        
    }
    
    update(){
        if(entrarGet){
            entrarGet = false;
            setTimeout(function() {
            get();
            entrarGet=true;
        }, delayInMilliseconds);
        }
        
        if(jugadores === 2){
            jugador1.setVisible(true);
            cuboAz.setVisible(true);
            jugador2.setVisible(false);
            cuboRo.setVisible(false);
            cuentaAtras.setVisible(false);
            
        }
        if(jugadores === 3){
            jugador1.setVisible(true);
            jugador2.setVisible(true);
            cuboAz.setVisible(true);
            cuboRo.setVisible(true);
            cuentaAtras.setVisible(true);
            setTimeout(function() {
                get();
                if(jugadores === 3){
                    cambioEscena = true;
                }
            }, 3000);
            if(cambioEscena){
                patron = 0;
                this.scene.start("juego");
            }          
        }
    }
}



