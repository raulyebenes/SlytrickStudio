


function get(callback){
    
    $.ajax({
        method: 'GET',
        url: 'jugadores/getNum',
        headers: {
            "Content-Type": "application/json",
        }
        
    }).done(function(data){
        //callback(data);
        jugadores = data;
        //console.log(jugadores);
    });
}


function conectarJug(){
    jugadores++;
    $.ajax({
        method: "PUT",
        url: 'jugadores/connect',
        data: jugadores,
        processData: false,
        headers: {
            "Content-Type": "application/json",
        }     
    }).done(function() {
            console.log("Conexion exitosa: " + jugadores + " jugadores");
    }).fail(function(){
            console.log("Error al conectar");
    });
}

function desconectarJug(){
    jugadores--;
    $.ajax({
        method: "PUT",
        url: 'jugadores/disconnect',
        data: jugadores,
        processData: false,
        headers: {
            "Content-Type": "application/json",
        }        
    }).done(function() {
            console.log("Desconexion exitosa: " + jugadores + " jugadores");
    }).fail(function(){
            console.log("Error al desconectar");
    });
}




   
   
