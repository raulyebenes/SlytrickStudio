

var delayInMilliseconds = 1000; //1 second
var entrarGet = true;

class Escena1 extends Phaser.Scene{

    constructor() {
        super("menu");
    }


    preload(){
        this.load.image("titulo", "assets/titulo.png");
        this.load.image("tituloR", "assets/tituloR.png");
        this.load.image("tituloAR", "assets/tituloAR.png");
        this.load.image("cubo_azul", "assets/cazultitulo.png");
        this.load.image("cubo_rojo", "assets/crojotitulo.png");
        this.load.image("botJugar", "assets/jugar.png");
        this.load.image("botInstrucciones", "assets/Instrucciones.png");
        this.load.image("botCreditos", "assets/creditos.png");
        this.load.image("fondo", "assets/fondo.png");
    }

    create() {
        //this.add.text(125 ,700, "Pulsa ENTER para iniciar");
        this.add.image(250,400, "fondo");
        this.add.image(250,150, "tituloAR").setScale(0.6);
        cuboAzul = this.add.image(120,350, "cubo_azul");
        cuboRojo = this.add.image(380,350, "cubo_rojo").setScale(0.6).setRotation(-60);

        cuboAzul.setScale(0.65).setRotation(60);
        cuboRojo.setScale(0.65).setRotation(-60);
        let botonJugar = this.add.image(game.config.width/2, 575, "botJugar");
        let botonInstrucciones = this.add.image(game.config.width/2, 695, "botInstrucciones");
        let botonCreditos = this.add.image(game.config.width/2, 770, "botCreditos").setScale(0.5);
        gameOver=false;
        
        botonJugar.setInteractive();
        botonInstrucciones.setInteractive();
        botonCreditos.setInteractive();
        
        get();
        
        botonJugar.on("pointerup", ()=>{
            if(jugadores == 1 || jugadores == 2){
                conectarJug();
                this.scene.start("lobby");
            }else {
                console.log("Ya hay dos jugadores jugando");
            }
        })
        
        
        
        botonInstrucciones.on("pointerup", ()=>{
            this.scene.start("instrucciones");
        })
        
        botonCreditos.on("pointerup", ()=>{
            this.scene.start("creditos");
        })
    }
    
    update(){
        if(entrarGet){
            entrarGet = false;
            setTimeout(function() {
            get();
            entrarGet=true;
        }, delayInMilliseconds);
        }
    }
    
}
