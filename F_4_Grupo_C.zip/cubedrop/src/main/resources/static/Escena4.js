/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



class Escena4 extends Phaser.Scene{

    constructor() {
        super("instrucciones");
    }
    
    preload(){
        this.load.image("panInstrucciones", "assets/pantallaInstrucciones.png");

    }
    
    create() {
        let fondo = this.add.image(game.config.width/2, game.config.height/2, "panInstrucciones");
        fondo.setInteractive();
        fondo.on("pointerup", ()=>{
            this.scene.start("menu");
        })
    }
    
   
}