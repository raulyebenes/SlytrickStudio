package es.sidelab.cubedrop;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;




@RestController
@RequestMapping("/ws")
public class WSHandler extends TextWebSocketHandler{
	
	String id;
	
	private ObjectMapper mapper;
	int usuariosMAX = 5;
	WebSocketSession[] usuarios = new WebSocketSession[usuariosMAX];
	int sesionesRegistradas = 0;
	
	public WSHandler() {
		
		mapper = new ObjectMapper();
	}
	
	@Override
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
		System.out.println("Message received: " + message.getPayload());
		System.out.println("ID Emisor: " + session.getId());
		
		//String mensaje = message.getPayload();
		//session.sendMessage(new TextMessage(mensaje));
		//session.sendMessage(new TextMessage(id));
		
		JsonNode nodo = mapper.readTree(message.getPayload());
		ObjectNode msg = mapper.createObjectNode();
		ObjectNode msg2 = mapper.createObjectNode();
		try {
		if(nodo.get("msg").asText().equals("registrar")) {
				if(sesionesRegistradas == 0) {
					usuarios[0] = session;
					msg.put("mensajeDevuelto", "Te has registrado el primero.");
					session.sendMessage(new TextMessage(msg.toString()));
					sesionesRegistradas++;
				}else if(sesionesRegistradas == 1 && usuarios[0].getId() != session.getId()) {
					usuarios[1] = session;
					msg.put("mensajeDevuelto", "Te has registrado el segundo.");
					session.sendMessage(new TextMessage(msg.toString()));
					sesionesRegistradas++;
					msg2.put("mensajeDevuelto", "Se ha conectado el otro usuario.");
					usuarios[0].sendMessage(new TextMessage(msg2.toString()));
				}
		} 
		}catch (Exception e){
			System.out.println("No has recibido un registro");
		}
		try {
		if(sesionesRegistradas >= 2) {	
			String IDemisor = session.getId();
			WebSocketSession sessionDestino = null;
			
			if(IDemisor == usuarios[0].getId()) {
				sessionDestino = usuarios[1];
			} else if(IDemisor == usuarios[1].getId()) {
				sessionDestino = usuarios[0];
			}
			//System.out.println("ID emisor " + IDemisor);
			//System.out.println("ID destino " + sessionDestino.getId());
			
			if(nodo.get("direccion").asInt() == 0) {
				msg.put("direccion", 0);
				sessionDestino.sendMessage(new TextMessage(msg.toString()));
			} else if(nodo.get("direccion").asInt() == 1) {
				msg.put("direccion", 1);
				sessionDestino.sendMessage(new TextMessage(msg.toString()));
			}else if(nodo.get("direccion").asInt() == 4) {
				msg.put("direccion", 4);
				sessionDestino.sendMessage(new TextMessage(msg.toString()));
			}
		}
		}catch (Exception e) {
			System.out.println("No has recibido una direccion");
		}
	}
}



