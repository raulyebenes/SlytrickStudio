package es.sidelab.cubedrop;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/jugadores")
public class AppController {
	
	@Autowired
	public Jugadores jugadores;
	
	@GetMapping(value="/getNum")
	@ResponseStatus(HttpStatus.CREATED)
	public int get(){
		return jugadores.getJugadores();
	}
	
	@PutMapping(value="/connect")
	public ResponseEntity<Boolean>conectado(@RequestBody int numero){
		/*int aux = jugadores.getJugadores();
		aux++;*/
		jugadores.setJugadores(numero);
		return new ResponseEntity<Boolean>(true, HttpStatus.OK);
	}
	
	@PutMapping(value="/disconnect")
	public ResponseEntity<Boolean>desconectado(@RequestBody int numero){
		/*int aux = jugadores.getJugadores();
		aux--;*/
		jugadores.setJugadores(numero);
		return new ResponseEntity<Boolean>(true, HttpStatus.OK);
	}
}


