


class Escena1 extends Phaser.Scene{

    constructor() {
        super("menu");
    }


    preload(){
        this.load.image("titulo", "assets/titulo.png");
        this.load.image("tituloR", "assets/tituloR.png");
        this.load.image("tituloAR", "assets/tituloAR.png");
        this.load.image("cubo_azul", "assets/cazultitulo.png");
        this.load.image("cubo_rojo", "assets/crojotitulo.png");
        this.load.image("botJugar", "assets/jugar.png");
        this.load.image("botInstrucciones", "assets/instrucciones.png");
        this.load.image("botCreditos", "assets/creditos.png");
        this.load.image("fondo", "assets/fondo.png");
    }

    create() {
        //this.add.text(125 ,700, "Pulsa ENTER para iniciar");
        this.add.image(250,400, "fondo");
        this.add.image(250,150, "tituloAR").setScale(0.6);
        cuboAzul = this.add.image(120,350, "cubo_azul");
        cuboRojo = this.add.image(380,350, "cubo_rojo").setScale(0.6).setRotation(-60);

        cuboAzul.setScale(0.65).setRotation(60);
        cuboRojo.setScale(0.65).setRotation(-60);
        let botonJugar = this.add.image(game.config.width/2, 575, "botJugar");
        let botonInstrucciones = this.add.image(game.config.width/2, 695, "botInstrucciones");
        let botonCreditos = this.add.image(game.config.width/2, 770, "botCreditos").setScale(0.5);
        gameOver=false;
        
        botonJugar.setInteractive();
        botonInstrucciones.setInteractive();
        botonCreditos.setInteractive();
        
        botonJugar.on("pointerup", ()=>{
            this.scene.start("juego");
        })
        
        botonInstrucciones.on("pointerup", ()=>{
            this.scene.start("instrucciones");
        })
        
        botonCreditos.on("pointerup", ()=>{
            this.scene.start("creditos");
        })
    }
    
}
