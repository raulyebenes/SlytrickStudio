
class Escena3 extends Phaser.Scene{

    constructor() {
        super("pausa");
    }
    
    create() {
        this.add.text(125 ,700, "Juego pausado pulsa enter para continuar");
        this.teclaR = this.input.keyboard.addKey('R');
    }
    
    upload() {
        if(this.teclaR.isDown){
            this.scene.resume('juego');
            this.scene.stop('pausa');
        }
    }
}


