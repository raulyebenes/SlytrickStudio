/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Escena2 extends Phaser.Scene{
    constructor() {
        super("juego");
        
    }
    
    preload(){
        this.load.image("fondo", "assets/ventana.png");
        //this.load.image("alien", "assets/alien.png");
        //this.load.image("asteroide", "assets/asteroide.png");
        this.load.image("plataforma", "assets/plataforma.png");
        this.load.image("plat_muelle", "assets/plat_muelle.png");
        this.load.image("plat_pegajoso", "assets/plat_pegajoso.png");
        this.load.image("plat_pinchos", "assets/plat_pinchos.png");
        this.load.image("cubo", "assets/cubo.png");
    }
    
    create() {
        /*randomPlat = Math.floor((Math.random() * 4));
        arrayPlat = ["plataforma", "plat_muelle", "plat_pegajoso", "plat_pinchos"];
        switch(randomPlat){
            case 0:
                this.plataforma = this.add.image(
                config.width/2, config.height/2, "plataforma");
                entra = true;
            break;
            
            case 1:
                this.plataforma = this.add.image(
                config.width/2, config.height/2, "plat_muelle");
        entra = true;
            break;
            
            case 2:
                this.plataforma = this.add.image(
                config.width/2, config.height/2, "plat_pegajoso");
            entra = true;
                break;
            
            case 3:
                this.plataforma = this.add.image(
                config.width/2, config.height/2, "plat_pinchos");
            entra = true;
                break;
        
        }*/
             
        this.background = this.add.tileSprite(0,0, config.width,
                config.height, "fondo");
        this.background.setOrigin(0,0);
        
        /*this.plataforma = this.add.image(
                config.width/2, config.height/2, arrayPlat[0]);
        this.plataforma = this.add.image(
                config.width/2+50, config.height/2, arrayPlat[1]);
        this.plataforma = this.add.image(
                config.width/2+100, config.height/2, arrayPlat[2]);
        this.plataforma = this.add.image(
                config.width/2+150, config.height/2, arrayPlat[3]);
        */
       
        //this.cubo = this.add.image(
          //      config.width/2, config.height/2-36, "cubo");
        
        this.add.text(20, 20, "Probando cositas guapis", {font:"25px Arial Black", fill: "black"});
        
        this.cubo = this.physics.add.sprite(50, config.height/2-36, "cubo");
        this.cubo.setCollideWorldBounds(true);
        
        this.cursors = this.input.keyboard.createCursorKeys();
        
    }
    
    crear_plataforma(){
                randomPlat = Math.floor((Math.random() * 4));
                arrayPlat = ["plataforma", "plat_muelle", "plat_pegajoso", "plat_pinchos"];
                /*switch(randomPlat){
                    case 0:
                        this.plataforma = this.add.image(
                        config.width/2, config.height/2, "plataforma");
                entra = true;
                    break;

                    case 1:
                        this.plataforma = this.add.image(
                        config.width/2, config.height/2, "plat_muelle");
                entra = true;
                    break;

                    case 2:
                        this.plataforma = this.add.image(
                        config.width/2, config.height/2, "plat_pegajoso");
                entra = true;
                        break;

                    case 3:
                        this.plataforma = this.add.image(
                        config.width/2, config.height/2, "plat_pinchos");
                entra = true;
                        break;

                }*/
        this.plataforma = this.add.image(
                config.width/2, config.height/2, arrayPlat[0]);
        this.plataforma = this.add.image(
                config.width/2+50, config.height/2, arrayPlat[1]);
        this.plataforma = this.add.image(
                config.width/2+100, config.height/2, arrayPlat[2]);
        this.plataforma = this.add.image(
                config.width/2+150, config.height/2, arrayPlat[3]);
       
    }
            
    update() {
        this.background.tilePositionY += 0;
        if(vel <= 10) {
            vel += 0.01;
        }
        if(flipflop){
            if (this.cursors.left.isDown){
                    flipflop = false;
                    crear_plataforma();
                    if(this.cubo.x >= 50){
                        this.physics.moveTo(
                                this.cubo, this.cubo.x-80, this.cubo.y, 60, 0.5);
                    }
                    

            }else if (this.cursors.right.isDown){
                    flipflop = false;
                    crear_plataforma();
                    if(this.cubo.x <= 450){
                        this.physics.moveTo(
                                this.cubo, this.cubo.x+80, this.cubo.y, 60, 0.5);
                    }

            }
        }
        if(this.cursors.right.isUp && this.cursors.left.isUp){
            flipflop=true;
        } 
    }
    
    
    
    /* function () {
        if(dir === "izq"){
            if(this.cubo.getPositionX() !== 50){
                //target = new Phaser.Math.Vector2();
                //target.y=this.cubo.getPositionY;
                this.cubo.x -= 80;
            }
        }else if(dir === "der"){
            if(this.cubo.getPositionX() !== 450){
                //target = new Phaser.Math.Vector2();
                //target.y=this.cubo.getPositionY;
                this.cubo.x += 80;
            }
        }
    } */
}
